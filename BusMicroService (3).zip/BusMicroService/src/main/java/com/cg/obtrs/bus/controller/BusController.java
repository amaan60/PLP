package com.cg.obtrs.bus.controller;

import java.math.BigInteger;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.cg.obtrs.bus.exception.InvalidArgumentException;
import com.cg.obtrs.bus.exception.InvalidBusIdException;
import com.cg.obtrs.bus.dto.BusDto;
import com.cg.obtrs.bus.entities.BusEntity;
import com.cg.obtrs.bus.services.BusService;

/* @RestController tells Spring that this is the Handler class and contains handler methods. Basically does combined job of @Controller and @ResponseBody
 * @RequestMapping annotation is used to map the web requests to specified
 * handler classes or methods
 * @CrossOrigin annotation is used to handle Cross-Origin-Resource-Sharing */

@RestController
@RequestMapping("/bus")
@CrossOrigin("http://localhost:4200")
public class BusController {

	@Autowired
	private BusService busService;
	final static Logger logger = Logger.getLogger(BusController.class);

	@Autowired
	RestTemplate restTemplate;

	/*
	 * Method to add a new bus
	 * 
	 * @param busDto
	 */
	@PostMapping("/new")
	public ResponseEntity<BusDto> addNewBus(@RequestBody BusDto busDto) {
		BusEntity bus = new BusEntity();
		bus.setBusId(busDto.getBusId());
		bus.setBusType(busDto.getBusType());
		bus.setSeatsBooked(busDto.getSeatsBooked());
		bus.setTotalSeats(busDto.getTotalSeats());
		bus.setSourceStation(busDto.getSourceStation());
		bus.setDestinationStation(busDto.getDestinationStation());
		bus.setBoardingTime(busDto.getBoardingTime());
		bus.setDropTime(busDto.getDropTime());
		bus.setFare(busDto.getFare());
		busService.addBus(bus);
		ResponseEntity<BusDto> response = new ResponseEntity<>(busDto, HttpStatus.OK);
		logger.info("A NEW BUS ADDED WITH THE BUS ID = " + busDto.getBusId());
		return response;
	}

	/*
	 * Method to search for a bus using source and destination
	 * 
	 * @param sourceStation
	 * 
	 * @param destinationStation
	 */
	@GetMapping("/searchbus/{sourceStation}+{destinationStation}")
	public ResponseEntity<List<BusEntity>> searchForBus(@PathVariable String sourceStation,
			@PathVariable String destinationStation) {
		List<BusEntity> busList = busService.searchBus(sourceStation, destinationStation);
		ResponseEntity<List<BusEntity>> response = new ResponseEntity<>(busList, HttpStatus.OK);
		return response;
	}

	// Method to fetch all source station
	@GetMapping("/allsource")
	public ResponseEntity<List<String>> findAllSourceStation() {
		List<String> sourceList = busService.findAllSourceStation();
		ResponseEntity<List<String>> response = new ResponseEntity<>(sourceList, HttpStatus.OK);
		return response;
	}

	// Method to fetch all destination station
	@GetMapping("/alldestination")
	public ResponseEntity<List<String>> findAllDestinationStation() {
		List<String> destinationList = busService.findAllDestinationStation();
		ResponseEntity<List<String>> response = new ResponseEntity<>(destinationList, HttpStatus.OK);
		return response;
	}
	/*
	 * Method to fetch bus by bus id
	 * 
	 * @param busId
	 * 
	 */

	@GetMapping("/busbyid/{busId}")
	public ResponseEntity<BusEntity> getBus(@PathVariable BigInteger busId) {
		BusEntity bus = busService.getBusById(busId);
		ResponseEntity<BusEntity> response = new ResponseEntity<>(bus, HttpStatus.OK);
		return response;
	}

	// Method to fetch all the operating buses
	@GetMapping("/buses")
	public ResponseEntity<List<BusEntity>> getAllBus() {
		List<BusEntity> bus = busService.getAllBus();
		ResponseEntity<List<BusEntity>> response = new ResponseEntity<>(bus, HttpStatus.OK);
		return response;
	}

	// Method to update the bus object
	@PutMapping("/update")
	public ResponseEntity<BusEntity> updateBus(@RequestBody BusEntity entity) {
		BusEntity bus = busService.updateBus(entity);
		ResponseEntity<BusEntity> response = new ResponseEntity<>(bus, HttpStatus.OK);
		logger.info("BUS WITH THE BUS ID = " + entity.getBusId() + " UPDATED.");
		return response;

	}

	/*
	 * Method to remove a bus
	 * 
	 * @param busId
	 */
	@DeleteMapping("/delete/{busId}")
	public boolean deleteBus(@PathVariable BigInteger busId) {
		boolean flag = busService.deleteBus(busId);
		logger.info("BUS REMOVED WITH THE BUS ID = " + busId);
		return true;
	}

	/*
	 * Handle Invalid BusId Exception
	 * 
	 * @param ex
	 */
	@ExceptionHandler(InvalidBusIdException.class)
	public ResponseEntity<String> handleBookingNotFound(InvalidBusIdException ex) {
		logger.error("INVALID BOOKING ID!!!", ex);
		String msg = ex.getMessage();
		ResponseEntity<String> response = new ResponseEntity<>(msg, HttpStatus.NOT_FOUND);
		return response;
	}

	/*
	 * Handle Bus not found Exception
	 * 
	 * @param ex
	 */
	@ExceptionHandler(InvalidArgumentException.class)
	public ResponseEntity<String> handleBookingNotFound(InvalidArgumentException ex) {
		logger.error("BOOKING NOT FOUND!!!", ex);
		String msg = ex.getMessage();
		ResponseEntity<String> response = new ResponseEntity<>(msg, HttpStatus.NOT_FOUND);
		return response;
	}

	/*
	 * Blanket Exception Handler
	 * 
	 * @param ex
	 */
	@ExceptionHandler(Throwable.class)
	public ResponseEntity<String> handleAll(Throwable ex) {
		logger.error("Something went wrong", ex);
		String msg = ex.getMessage();
		ResponseEntity<String> response = new ResponseEntity<>(msg, HttpStatus.INTERNAL_SERVER_ERROR);
		return response;
	}

}
