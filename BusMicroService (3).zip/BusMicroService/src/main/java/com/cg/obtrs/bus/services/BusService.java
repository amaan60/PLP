package com.cg.obtrs.bus.services;

import java.math.BigInteger;
import java.util.List;

import com.cg.obtrs.bus.entities.BusEntity;
import com.cg.obtrs.bus.exception.InvalidArgumentException;
import com.cg.obtrs.bus.exception.InvalidBusIdException;

public interface BusService {
	List<BusEntity> searchBus(String sourceStation, String destinationStation);

	List<String> findAllSourceStation();

	List<String> findAllDestinationStation();

	BusEntity getBusById(BigInteger busId) throws InvalidBusIdException;

	BusEntity updateBus(BusEntity bus) throws InvalidArgumentException;

	List<BusEntity> getAllBus();

	boolean deleteBus(BigInteger busId) throws InvalidBusIdException;

	BusEntity addBus(BusEntity bus) throws InvalidArgumentException;

}
