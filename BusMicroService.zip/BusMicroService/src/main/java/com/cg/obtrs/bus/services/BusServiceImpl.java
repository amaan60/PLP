package com.cg.obtrs.bus.services;

import java.math.BigInteger;
import java.util.List;
import java.util.Optional;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.obtrs.bus.controller.BusController;
import com.cg.obtrs.bus.dao.BusDao;
import com.cg.obtrs.bus.entities.BusEntity;
import com.cg.obtrs.bus.exception.CustomException;

@Service
public class BusServiceImpl implements BusService {

	@Autowired
	BusDao busRepository;
	final static Logger logger = Logger.getLogger(BusServiceImpl.class);

	@Override
	public BusEntity getBusById(BigInteger busId) throws CustomException {
		Optional<BusEntity> optional = busRepository.findById(busId);
		if (optional.isPresent()) {
			BusEntity bus = optional.get();
			return bus;
		} else {
			logger.error("BUS NOT FOUND WITH THE BUS ID = " + busId);
			throw new CustomException("Sorry, Bus Not Found");
		}
	}

	@Override
	public BusEntity updateBus(BusEntity bus) throws CustomException {
		return busRepository.save(bus);
	}

	@Override
	public List<BusEntity> searchBus(String sourceStation, String destinationStation) throws CustomException {
		return busRepository.searchBus(sourceStation, destinationStation);
	}

	@Override
	public List<String> findAllSourceStation() throws CustomException {
		return busRepository.findAllSourceStation();
	}

	@Override
	public List<String> findAllDestinationStation() throws CustomException {
		return busRepository.findAllDestinationStation();
	}

	@Override
	public List<BusEntity> getAllBus() throws CustomException {
		return busRepository.findAll();
	}

	@Override
	public boolean deleteBus(BigInteger busId) throws CustomException {
		Optional<BusEntity> optional = busRepository.findById(busId);
		if (optional.isPresent()) {
			busRepository.deleteById(busId);
			return true;
		} else {
			logger.error("BUS NOT FOUND WITH THE BUS ID = " + busId);
			throw new CustomException("Sorry, Bus Not Found");
		}
	}

	@Override
	public BusEntity addBus(BusEntity bus) throws CustomException {
		return busRepository.save(bus);
	}

}
