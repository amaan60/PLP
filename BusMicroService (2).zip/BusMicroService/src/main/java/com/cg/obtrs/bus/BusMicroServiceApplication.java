package com.cg.obtrs.bus;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.context.annotation.Bean;
import org.springframework.web.client.RestTemplate;
/* 
 * @SpringBootApplication annotation does the combined work for @ComponentScan, @Configuration and @EnableAutoConfiguration.
 * @EnableDiscoveryClient annotation mark the service as Discovery client to register itself on the EurekaServer
 */
@SpringBootApplication
@EnableDiscoveryClient
public class BusMicroServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(BusMicroServiceApplication.class, args);
	}
	
	@Bean
	@LoadBalanced
	public RestTemplate restTemplate() {
		return new RestTemplate();
	}

}
