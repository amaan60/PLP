package com.cg.obtrs.booking.services;

import java.math.BigInteger;
import java.util.List;
import java.util.Optional;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;

import com.cg.obtrs.booking.entities.BookingEntity;
import com.cg.obtrs.booking.exception.CustomException;

public interface BookingService 
{
	 List<BookingEntity> getAllBooking() throws CustomException;
	
	 BookingEntity getBookingById(BigInteger bookingId) throws CustomException;
	
	 BookingEntity addBooking(BookingEntity entity) throws CustomException;
	
	 boolean cancelBooking( BigInteger bookingId) throws CustomException;
}
