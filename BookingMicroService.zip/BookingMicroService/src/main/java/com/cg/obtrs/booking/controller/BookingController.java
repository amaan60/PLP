package com.cg.obtrs.booking.controller;
import java.math.BigInteger;
import java.util.List;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.cg.obtrs.booking.dto.BookingDto;
import com.cg.obtrs.booking.entities.BookingEntity;
import com.cg.obtrs.booking.entities.BusEntity;
import com.cg.obtrs.booking.services.BookingService;


@RestController
@RequestMapping("/booking")
@CrossOrigin("http://localhost:4200")
public class BookingController {

	@Autowired
	private BookingService bookingService;
	
	@Autowired
	private RestTemplate restTemplate;

	
	final static Logger logger = Logger.getLogger(BookingController.class);
	
	//Consuming Bus MicroService to get all the source station. 
	@GetMapping("/source") 
	public ResponseEntity<List<String>> getAllSourceStation() {
		String url = "http://localhost:8082/bus/allsource";
		List<String> source = restTemplate.getForObject(url, List.class);
		ResponseEntity<List<String>> response = new ResponseEntity<>(source, HttpStatus.OK);
		return response;
	}
	
	//Consuming Bus MicroService to get all the destination station.
	@GetMapping("/destination") 
	public ResponseEntity<List<String>> getAllDestinationStation() {
		String url = "http://localhost:8082/bus/alldestination";
		List<String> source = restTemplate.getForObject(url, List.class);
		ResponseEntity<List<String>> response = new ResponseEntity<>(source, HttpStatus.OK);
		return response;
	}
	
   //Consuming Bus MicroService to search for a bus based on source and destination
	@GetMapping("/searchbus/{sourceStation}+{destinationStation}")
	public ResponseEntity<List<BusEntity>> searchForBus(@PathVariable String sourceStation, @PathVariable String destinationStation){
		String url = "http://localhost:8082/bus/searchbus/"+sourceStation+"+"+destinationStation;
		List<BusEntity> bus = restTemplate.getForObject(url, List.class);
		ResponseEntity<List<BusEntity>> response = new ResponseEntity<>(bus, HttpStatus.OK);
		return response;
	}
	//Consuming Bus MicroService to get all operating buses.
	@GetMapping("/buses") 
	public ResponseEntity<List<BusEntity>> getAllBuses() {
		String url = "http://localhost:8082/bus/buses";
		List<BusEntity> bus = restTemplate.getForObject(url, List.class);
		ResponseEntity<List<BusEntity>> response = new ResponseEntity<>(bus, HttpStatus.OK);
		return response;
	}
	//Consuming Bus MicroService to fetch bus using Id.
	@GetMapping("/busbyid/{busId}")
	public ResponseEntity<BusEntity> getBus(@PathVariable BigInteger busId) {
		String url = "http://localhost:8082/bus/busbyid/"+busId;
		BusEntity bus = restTemplate.getForObject(url, BusEntity.class);
		ResponseEntity<BusEntity> response = new ResponseEntity<>(bus, HttpStatus.OK);
		return response;
	}
	  /*Consuming Bus Microservice to update Bus 
	   * when done a new Booking is added*/
	@PutMapping("/updatebus") 
	public ResponseEntity<BusEntity> updateBus(@RequestBody BusEntity entity) {
		String url = "http://localhost:8082/bus/update";
		BusEntity bus = restTemplate.getForObject(url, BusEntity.class);
		ResponseEntity<BusEntity> response = new ResponseEntity<>(bus, HttpStatus.OK);
		return response;
	}
	
	
	@PostMapping("/new")
    public ResponseEntity<BookingEntity> addNewBooking(@RequestBody BookingEntity entity) {
		BookingEntity booking = bookingService.addBooking(entity);
		ResponseEntity<BookingEntity> response = new ResponseEntity<>(booking, HttpStatus.OK);
		logger.info("A NEW BOOKING ADDED WITH THE BOOKING ID = "+ entity.getBookingId());
		return response;
	}
	
	@GetMapping("/bookingbyid/{bookingId}")
	public ResponseEntity<BookingEntity> getBookingById(@PathVariable BigInteger bookingId) {
		BookingEntity booking = bookingService.getBookingById(bookingId);
		ResponseEntity<BookingEntity> response = new ResponseEntity<>(booking, HttpStatus.OK);
		return response;
	}
	
	@GetMapping("/booking")
	public ResponseEntity<List<BookingEntity>> getAllBooking() {
		List<BookingEntity> booking = bookingService.getAllBooking();
		ResponseEntity<List<BookingEntity>> response = new ResponseEntity<>(booking, HttpStatus.OK);
		return response;
	}
	
	@DeleteMapping("/delete/{bookingId}")
	public boolean cancelBooking(@PathVariable BigInteger bookingId) {
		bookingService.cancelBooking(bookingId);
		logger.info("BOOKING REMOVED WITH THE BOOKING ID = " + bookingId);
		return true;
	}
	
	public BookingEntity convertFromBookingDto(BookingDto bookingDto) {
		BookingEntity booking = new BookingEntity();
		booking.setBookingId(bookingDto.getBookingId());
		booking.setBusId(bookingDto.getBusId());
		booking.setPassengerNames(bookingDto.getPassengerNames());
		booking.setSeatsBooked(bookingDto.getSeatsBooked());
		booking.setSeatNo(bookingDto.getSeatNo());
		booking.setTotalFare(bookingDto.getTotalFare());
		return booking;
		}
}
