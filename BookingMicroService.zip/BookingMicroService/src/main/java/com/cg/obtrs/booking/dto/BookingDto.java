package com.cg.obtrs.booking.dto;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

public class BookingDto {

	//Booking details
	private int bookingId;
	private int busId;
	private float totalFare;
	private Date bookingDate;
    //Passenger details
	private List<String> passengerNames = new ArrayList<>();
	private Integer seatsBooked;
	private String seatNo;

	public BookingDto() {
		super();
	}

	public BookingDto(int busId, List<String> passengerNames, Integer seatsBooked, float totalFare, int bookingId,
			String seatNo, Date bookingDate) {
		super();
		this.busId = busId;
		this.passengerNames = passengerNames;
		this.seatsBooked = seatsBooked;
		this.totalFare = totalFare;
		this.bookingId = bookingId;
		this.seatNo = seatNo;
		this.bookingDate = bookingDate;
	}

	public int getBusId() {
		return busId;
	}

	public void setBusId(int busId) {
		this.busId = busId;
	}

	public Integer getSeatsBooked() {
		return seatsBooked;
	}

	public void setSeatsBooked(Integer seatsBooked) {
		this.seatsBooked = seatsBooked;
	}

	public List<String> getPassengerNames() {
		return passengerNames;
	}

	public void setPassengerNames(List<String> passengerNames) {
		this.passengerNames = passengerNames;
	}

	public float getTotalFare() {
		return totalFare;
	}

	public void setTotalFare(float totalFare) {
		this.totalFare = totalFare;
	}

	public int getBookingId() {
		return bookingId;
	}

	public void setBookingId(int bookingId) {
		this.bookingId = bookingId;
	}

	public String getSeatNo() {
		return seatNo;
	}

	public void setSeatNo(String seatNo) {
		this.seatNo = seatNo;
	}

	public Date getBookingDate() {
		return bookingDate;
	}

	public void setBookingDate(Date bookingDate) {
		this.bookingDate = bookingDate;
	}

	@Override
	public String toString() {
		return "BookingDTO [busId=" + busId + ", passengerNames=" + passengerNames + ", seatsBooked=" + seatsBooked
				+ ", totalFare=" + totalFare + "]";
	}

}
