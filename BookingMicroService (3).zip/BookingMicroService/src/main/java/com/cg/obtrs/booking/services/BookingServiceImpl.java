package com.cg.obtrs.booking.services;

import java.math.BigInteger;
import java.util.List;
import java.util.Optional;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.obtrs.booking.dao.BookingDao;
import com.cg.obtrs.booking.entities.BookingEntity;
import com.cg.obtrs.booking.exception.InvalidArgumentException;
import com.cg.obtrs.booking.exception.InvalidBookingIdException;

@Service
public class BookingServiceImpl implements BookingService {
	@Autowired
	BookingDao bookingDao;

	final static Logger logger = Logger.getLogger(BookingServiceImpl.class);

	@Override
	public List<BookingEntity> getAllBooking() {
		return bookingDao.findAll();
	}

	@Override
	public BookingEntity getBookingById(BigInteger bookingId) throws InvalidBookingIdException {
		Optional<BookingEntity> optional = bookingDao.findById(bookingId);
		if (optional.isPresent()) {
			BookingEntity booking = optional.get();
			return booking;
		} else {
			logger.error("BOOKING NOT FOUND WITH THE BOOKING ID = " + bookingId);
			throw new InvalidBookingIdException("Sorry, Booking Not Found");
		}
	}

	@Override
	public BookingEntity addBooking(BookingEntity booking) throws InvalidArgumentException {
		if (booking == null) {
			throw new InvalidArgumentException("Booking can't be null");
		}
		return bookingDao.save(booking);
	}

	@Override
	public boolean cancelBooking(BigInteger bookingId) throws InvalidBookingIdException {
		Optional<BookingEntity> optional = bookingDao.findById(bookingId);
		if (optional.isPresent()) {
			bookingDao.deleteById(bookingId);
			return true;
		} else {
			logger.error("BOOKING NOT FOUND WITH THE BOOKING ID = " + bookingId);
			throw new InvalidBookingIdException("Sorry, Booking Not Found");
		}
	}

	@Override
	public BookingEntity modifyBooking(BookingEntity booking) throws InvalidBookingIdException {
		if (booking == null) {
			throw new InvalidArgumentException("Booking can't be null");
		}
		return bookingDao.save(booking);
	}

}
