package com.cg.obtrs.booking.exception;

public class InvalidBookingIdException extends RuntimeException {
	public InvalidBookingIdException(String msg) {
		super(msg);
	}
}
