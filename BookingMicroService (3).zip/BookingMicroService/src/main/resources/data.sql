insert into booking values(123212.00, '2020-05-13', 1456.00, "amaan.ahmad7@gmail.com", 5, '1A',1,900);
insert into booking values(343224.00, '2020-05-14', 3456.00, "yhad2.hsiva7@gmail.com", 4, '1A 2B',2,1900);
insert into booking values(489835.00, '2020-05-12', 5439.00	, "shivam.singh@gmail.com", 4, '1A 1B 7A',3, 2700);
insert into booking values(623242.00, '2020-05-13', 1456.00, "amaan.ahmad7@gmail.com", 5, '5A',1,900);
insert into booking values(324252.00, '2020-05-14', 1456.00, "yash.abhya7@gmail.com", 5, '5A',1,900);
insert into booking values(723614.00, '2020-05-12', 1456.00, "shivani.asda7@gmail.com", 4, '5A',1,900);
insert into booking values(324272.00, '2020-05-11', 1233.00, "amaan.ahmad7@gmail.com", 5, '5A',1,1500);
insert into booking values(5262127.00, '2020-05-13', 1233.00, "adeeb.ahmad@gmail.com", 5, '5A',1,1500);
insert into booking values(423213.00, '2020-05-10', 1456.00, "amaan.ahmad7@gmail.com", 5, '5A',1,900);

