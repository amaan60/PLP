package com.cg.obtrs.booking.controller;

import java.math.BigInteger;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;
import com.cg.obtrs.booking.entities.BookingEntity;
import com.cg.obtrs.booking.entities.BusEntity;
import com.cg.obtrs.booking.exception.CustomException;
import com.cg.obtrs.booking.services.BookingService;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

/* @RestController tells Spring that this is the Handler class and contains handler methods. Basically does combined job of @Controller and @ResponseBody
 * @RequestMapping annotation is used to map the web requests to specified 
 * handler classes or methods
 * @CrossOrigin annotation is used to handle Cross-Origin-Resource-Sharing */
@RestController
@RequestMapping("/booking")
@CrossOrigin("http://localhost:4200")
public class BookingController {

	@Autowired
	private BookingService bookingService;

	@Autowired
	private RestTemplate restTemplate;

	final static Logger logger = Logger.getLogger(BookingController.class);

	/*
	 * Method that consumes Bus MicroService to get all the source station.
	 * 
	 * @HystrixCommand annotation to implement CircuitBreaker and call the fallback
	 * methods is case of failure of interacting MicroService
	 */
	@HystrixCommand(fallbackMethod = "getFallBackSourceStation")
	@GetMapping("/source")
	public ResponseEntity<List<String>> getAllSourceStation() {
		String url = "http://BUS-INFO-SERVICE/bus/allsource";
		List<String> source = restTemplate.getForObject(url, List.class);
		ResponseEntity<List<String>> response = new ResponseEntity<>(source, HttpStatus.OK);
		return response;
	}
	/*
	 * Fallback method in case of failure to getAllSourceStation from
	 * BusMicroservice
	 */
	public ResponseEntity<List<String>> getFallBackSourceStation() {
		List<String> source = new ArrayList<String>(Arrays.asList("Delhi", "Kolkata"));
		ResponseEntity<List<String>> response = new ResponseEntity<>(source, HttpStatus.OK);
		return response;
	}
	
	// Method to consume Bus MicroService to get all the destination station.
	@HystrixCommand(fallbackMethod = "getFallBackDestinationStation")
	@GetMapping("/destination")
	public ResponseEntity<List<String>> getAllDestinationStation() {
		String url = "http://BUS-INFO-SERVICE/bus/alldestination";
		List<String> source = restTemplate.getForObject(url, List.class);
		ResponseEntity<List<String>> response = new ResponseEntity<>(source, HttpStatus.OK);
		return response;
	}

	/*
	 * FallBack method for the failure of getAllDestinationStation from
	 * BusMicroservice
	 */
	public ResponseEntity<List<String>> getFallBackDestinationStation() {
		List<String> source = new ArrayList<String>(Arrays.asList("Lucknow", "Mumbai"));
		ResponseEntity<List<String>> response = new ResponseEntity<>(source, HttpStatus.OK);
		return response;
	}

	/*
	 * Method to consume Bus MicroService to search for a bus based on source and
	 * destination
	 */
	@HystrixCommand(fallbackMethod = "getFallBackSearchBus")
	@GetMapping("/searchbus/{sourceStation}+{destinationStation}")
	public ResponseEntity<List<BusEntity>> searchForBus(@PathVariable String sourceStation,
			@PathVariable String destinationStation) {
		String url = "http://BUS-INFO-SERVICE/bus/searchbus/" + sourceStation + "+" + destinationStation;
		List<BusEntity> bus = restTemplate.getForObject(url, List.class);
		ResponseEntity<List<BusEntity>> response = new ResponseEntity<>(bus, HttpStatus.OK);
		return response;
	}

	// FallBack method in case of the failure of searchBus from BusMicroservice
	public ResponseEntity<List<BusEntity>> getFallBackSearchBus(@PathVariable String sourceStation,
			@PathVariable String destinationStation) throws CustomException {
		List<BusEntity> busList = new ArrayList<>();
		boolean flag = false;
		List<BusEntity> bus = getBusEntityObject();
		for (BusEntity busEntity : bus) {
			if (busEntity.getSourceStation().equalsIgnoreCase(sourceStation)
					&& busEntity.getDestinationStation().equalsIgnoreCase(destinationStation)) {
				busList.add(busEntity);
				flag = true;
			}
		}
		if (flag == true) {
			ResponseEntity<List<BusEntity>> response = new ResponseEntity<>(busList, HttpStatus.OK);
			return response;
		} else {
			throw new CustomException("Sorry, No Buses Operating on this route");
		}
	}

	// Method to consume Bus MicroService to get all currently operating buses.
	@HystrixCommand(fallbackMethod = "getFallBackAllBus")
	@GetMapping("/buses")
	public ResponseEntity<List<BusEntity>> getAllBuses() {
		String url = "http://BUS-INFO-SERVICE/bus/buses";
		List<BusEntity> bus = restTemplate.getForObject(url, List.class);
		ResponseEntity<List<BusEntity>> response = new ResponseEntity<>(bus, HttpStatus.OK);
		return response;
	}

	//FallBack method for the failure of searchBus from BusMicroservice
	public ResponseEntity<List<BusEntity>> getFallBackAllBus() {
		List<BusEntity> bus = getBusEntityObject();
		ResponseEntity<List<BusEntity>> response = new ResponseEntity<>(bus, HttpStatus.OK);
		return response;
	}

	// Method to consume Bus MicroService that fetches bus using bus id.
	@HystrixCommand(fallbackMethod = "getFallBackBus")
	@GetMapping("/busbyid/{busId}")
	public ResponseEntity<BusEntity> getBus(@PathVariable BigInteger busId) {
		String url = "http://BUS-INFO-SERVICE/bus/busbyid/" + busId;
		BusEntity bus = restTemplate.getForObject(url, BusEntity.class);
		ResponseEntity<BusEntity> response = new ResponseEntity<>(bus, HttpStatus.OK);
		return response;
	}

	// FallBack method in case of failure of getBus from BusMicroservice
	public ResponseEntity<BusEntity> getFallBackBus(@PathVariable BigInteger busId) throws CustomException {
		ResponseEntity<BusEntity> response = null;
		boolean flag = false;
		List<BusEntity> bus = getBusEntityObject();
		for (BusEntity busEntity : bus) {
			if (busEntity.getBusId() == busId) {
				response = new ResponseEntity<>(busEntity, HttpStatus.OK);
				flag = true;
				break;
			}
		}
		if (flag == true) {
			return response;
		} else
			throw new CustomException("Sorry, No Bus Available");
	}

	// Consuming Bus MicroService to update bus when done a new booking is added
	@PutMapping("/updatebus")
	public ResponseEntity<BusEntity> updateBus(@RequestBody BusEntity entity) {
		String url = "http://BUS-INFO-SERVICE/bus/update";
		HttpEntity<BusEntity> requestEntity = new HttpEntity<>(entity);
		ResponseEntity<BusEntity> response = restTemplate.exchange(url, HttpMethod.PUT, requestEntity, BusEntity.class);
		return response;
	}

	@PostMapping("/new")
	public ResponseEntity<BookingEntity> addNewBooking(@RequestBody BookingEntity entity) {
		BookingEntity booking = bookingService.addBooking(entity);
		ResponseEntity<BookingEntity> response = new ResponseEntity<>(booking, HttpStatus.OK);
		logger.info("A NEW BOOKING ADDED WITH THE BOOKING ID = " + entity.getBookingId());
		return response;
	}

	@GetMapping("/bookingbyid/{bookingId}")
	public ResponseEntity<BookingEntity> getBookingById(@PathVariable BigInteger bookingId) {
		BookingEntity booking = bookingService.getBookingById(bookingId);
		ResponseEntity<BookingEntity> response = new ResponseEntity<>(booking, HttpStatus.OK);
		return response;
	}

	@GetMapping("/booking")
	public ResponseEntity<List<BookingEntity>> getAllBooking() {
		List<BookingEntity> booking = bookingService.getAllBooking();
		ResponseEntity<List<BookingEntity>> response = new ResponseEntity<>(booking, HttpStatus.OK);
		return response;
	}

	@DeleteMapping("/delete/{bookingId}")
	public boolean cancelBooking(@PathVariable BigInteger bookingId) {
		bookingService.cancelBooking(bookingId);
		logger.info("BOOKING REMOVED WITH THE BOOKING ID = " + bookingId);
		return true;
	}

	public List<BusEntity> getBusEntityObject() {
		List<BusEntity> bus = new ArrayList<>();
		BusEntity busEntity = new BusEntity();
		BigInteger bigInteger = BigInteger.valueOf(111);
		busEntity.setBusId(bigInteger);
		busEntity.setBusType("VOLVO");
		busEntity.setSourceStation("Delhi");
		busEntity.setDestinationStation("Lucknow");
		LocalDateTime boardingTime = LocalDateTime.of(2020, 5, 16, 10, 30, 30);
		busEntity.setBoardingTime(boardingTime);
		LocalDateTime dropTime = LocalDateTime.of(2020, 5, 17, 05, 15, 30);
		busEntity.setDropTime(dropTime);
		busEntity.setFare(700f);
		busEntity.setSeatsBooked(11);
		busEntity.setTotalSeats(40);
		bus.add(busEntity);
		return bus;
	}
}
